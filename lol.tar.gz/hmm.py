import json
import http.client
import requests
import discord
from discord.ext import tasks, commands
import os

# Discord bot token
DISCORD_TOKEN = "MTIyNjIzNzA3MDcwNDUxMzExNg.GxF5ot.13VoPCRfbP0sBsmwKFlH15O0SgQN9exqeUVh6M"
# Server ID where the channel will be created
SERVER_ID = "1226236826822508684"
# Filebin bin ID
FILEBIN_BIN_ID = "jh3ga2lgq6xaaxzn"
# Webhook URL to check
# Path to data.json file
DATA_JSON_PATH = "database/data.json"
NEW_WEBHOOK_URL_FILE = "new_webhook_url.txt"

# Define intents
intents = discord.Intents.all()
intents.guilds = True
intents.messages = True
intents.webhooks = True

bot = commands.Bot(command_prefix="!", intents=intents)

new_channel_id = None
new_webhook_url = None

# Function to check if the webhook is alive
async def is_webhook_alive(webhook_url):
    try:
        response = requests.get(webhook_url)
        return response.status_code == 200
    except requests.exceptions.RequestException:
        return False

# Function to create a new channel and update data.json
async def create_new_channel_and_update_data():
    global new_channel_id, new_webhook_url
    guild = bot.get_guild(int(SERVER_ID))
    if new_channel_id is not None:
        # Find the old channel and rename it
        old_channel = discord.utils.get(guild.channels, id=new_channel_id)
        if old_channel:
            await old_channel.edit(name="❌DEAD")  # Edit the channel name
    # Create a new channel
    new_channel = await guild.create_text_channel('✅LATEST')
    new_channel_id = new_channel.id
    # Create webhook under the new channel
    new_webhook = await new_channel.create_webhook(name="new-webhook")
    new_webhook_url = new_webhook.url
    # Update data.json with the new webhook URL and new channel ID
    data = {'webhook_url': new_webhook_url}
    with open(DATA_JSON_PATH, 'w') as json_file:
        json.dump(data, json_file)
    # Dump new webhook URL to text file for checking
    with open(NEW_WEBHOOK_URL_FILE, 'w') as url_file:
        url_file.write(new_webhook_url)
    # Delete old data.json from Filebin
    delete_url = f"https://filebin.net/{FILEBIN_BIN_ID}/data.json"
    requests.delete(delete_url)
    # Upload updated data.json to Filebin using http.client
    with open(DATA_JSON_PATH, 'rb') as json_file:
        conn = http.client.HTTPSConnection("filebin.net")
        headers = {
            'Content-Type': 'application/json',
            'Content-Length': os.path.getsize(DATA_JSON_PATH),
            'Content-Disposition': 'attachment; filename="data.json"'
        }
        conn.request("POST", f"/{FILEBIN_BIN_ID}/data.json", json_file, headers)
        response = conn.getresponse()
        print(response.read().decode())
    print("Data.json uploaded to Filebin.")

    # Check if the new webhook is alive
    if not await is_webhook_alive(new_webhook_url):
        print("New webhook is not alive. Recreating...")
        await create_new_channel_and_update_data()

# Function to recreate the channel and webhook if necessary
async def recreate_channel_and_webhook():
    await create_new_channel_and_update_data()

# Function to check the status of the webhook URL stored in the text file
async def check_webhook_status():
    with open(NEW_WEBHOOK_URL_FILE, 'r') as url_file:
        webhook_url = url_file.read().strip()  # Read and strip whitespace
        if await is_webhook_alive(webhook_url):
            print("Webhook is alive.")
        else:
            print("Webhook is not alive. Recreating...")
            await recreate_channel_and_webhook()

# Task to periodically check webhook status
@tasks.loop(seconds=600)
async def check_webhook():
    print("Checking webhook status...")
    await check_webhook_status()

# Start the bot
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")
    check_webhook.start()

bot.run(DISCORD_TOKEN)
